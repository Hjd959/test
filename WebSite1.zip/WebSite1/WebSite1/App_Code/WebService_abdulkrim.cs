﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Summary description for WebService_abdulkrim
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class WebService_abdulkrim : System.Web.Services.WebService
{

    public WebService_abdulkrim()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HiWorld()
    {
        return "Hello abdulkrim";
    }
    [WebMethod]
    public string getname(int enter_your_old)
    {

        if (enter_your_old > 18)
        {
            return "you can enter";
        }
        return "no";
    }
    [WebMethod(MessageName  = "addCar",Description ="this function add a car to dataBase if car made after 1999")]
    [System.Xml.Serialization.XmlInclude(typeof(car))]
    public String addCar(String name , int modul)
    {
        if (modul > 1999)
        {
            // car c_obj = new car(name, modul);
            car c = new car();
            c.name = name;
            c.modul = modul;
            return "good";
        }
        else
        {
            return "fail";
        }
    }

}
