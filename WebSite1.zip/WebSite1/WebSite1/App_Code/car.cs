﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for car
/// </summary>
public class car
{

   
    public string name { set; get; }
    public int modul { get; set; }
   
}